Francisco Camacho Cervantes fcamachocervantes@mines.edu
WeathrTrackr A4

Everything in the app works as expected the only thing that wasn't implemented was
the weather api. So the markers don't store or request the weather.

For getting the snack bar to pop up you need to click on a marker then click on little
title section that pop up above it to see the snack bar.

1. Initially getting the drawer set up was quite hard and confusing.
I was able to find a tutorial however which made it much clearer and helped me
make the drawer much easier. 

2. Adding a way to change information on the map would be a good idea since
it could show other useful information or alternatively a user could get rid
of information they don't find useful.