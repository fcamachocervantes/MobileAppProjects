package com.csci448.fcamachocervantes_a3

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.rememberNavController
import com.csci448.fcamachocervantes_a3.presentation.navigation.MovieNavHost
import com.csci448.fcamachocervantes_a3.presentation.navigation.MovieTopBar
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.IMovieViewModel
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.MovieViewModel
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.MovieViewModelFactory
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.PreviewMovieViewModel
import com.csci448.fcamachocervantes_a3.ui.theme.Fcamachocervantes_A3Theme

class MainActivity : ComponentActivity() {
    companion object {
        private const val LOG_TAG = "448.MainActivity"
    }

    private lateinit var mMovieViewModel: MovieViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(LOG_TAG, "onCreate() called")

        val factory = MovieViewModelFactory(this)
        mMovieViewModel = ViewModelProvider(this, factory)[factory.getViewModelClass()]
        setContent {
            MainActivityContent(movieViewModel = mMovieViewModel)
        }
    }
}

@Composable
private fun MainActivityContent(movieViewModel: IMovieViewModel) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    Fcamachocervantes_A3Theme {
        // A surface container using the 'background' color from the theme
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Scaffold(
                topBar = {
                    MovieTopBar(movieViewModel = movieViewModel, navHostController = navController, context = context)
                },
                content = {
                        paddingValues ->
                    MovieNavHost(
                        modifier = Modifier.padding(paddingValues),
                        navController = navController,
                        movieViewModel = movieViewModel,
                        context = context,
                        coroutineScope = coroutineScope
                    )
                }
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    val context = LocalContext.current
    val viewModel = PreviewMovieViewModel(context)
    MainActivityContent(movieViewModel = viewModel)
}