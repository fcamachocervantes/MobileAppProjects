package com.csci448.fcamachocervantes_a3.presentation.viewmodel

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import com.csci448.fcamachocervantes_a3.data.Movie
import kotlinx.coroutines.flow.StateFlow
import java.util.*

interface IMovieViewModel {
    val movieListState: StateFlow<List<Movie>>
    val currentMovieState: StateFlow<Movie?>
    val currentMovieString: MutableState<String?>
    fun loadMovieByUUID(uuid: String)
    fun addMovie(movie: Movie)
    fun deleteMovie(movie: Movie)
}