package com.csci448.fcamachocervantes_a3.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.util.*

@Entity(tableName = "movie")
data class Movie(val name: String,
                 val genre: String,
                 val stars: String,
                 val year: String,
                 val rank: Int,
                 @PrimaryKey
                 val id: String,
                 val imageUrl: String)

