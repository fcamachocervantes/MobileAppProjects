package com.csci448.fcamachocervantes_a3.presentation.list

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.csci448.fcamachocervantes_a3.data.Movie
import com.csci448.fcamachocervantes_a3.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovieListItem(
    movie: Movie,
    onSelectMovie: (Movie) -> Unit
) {
    val fontSize = 14.sp
    val isFavorite = remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        onClick = { onSelectMovie(movie) }
    ) {
        Row(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth()
                .padding(2.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(2.dp)
            ) {
                Text(
                    modifier = Modifier.padding(2.dp),
                    text = movie.name,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = fontSize
                )
                Text(
                    modifier = Modifier
                        .padding(2.dp),
                    text = movie.stars,
                    fontSize = fontSize,
                    textAlign = TextAlign.Start
                )
            }
            Column(
                modifier = Modifier
                    .padding(2.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Bottom
            ){
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ){
                    Text(
                        modifier = Modifier
                            .padding(2.dp),
                        text = movie.year,
                        fontSize = fontSize,
                        textAlign = TextAlign.Right
                    )
                    IconToggleButton(
                        checked = isFavorite.value,
                        onCheckedChange = {
                            isFavorite.value = !isFavorite.value
                        }
                    ) {
                        Icon(
                            imageVector =
                                if(isFavorite.value) {
                                    Icons.Filled.Favorite
                                }
                                else {
                                    Icons.Default.FavoriteBorder

                            },
                            contentDescription = stringResource(id = R.string.menu_back_desc)
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun PreviewMovieListItem() {
    val movie = Movie("The Mandalorian", "Scifi", "Pedro Pascal, Someone Else", "2023", 9, "210480", "")
    MovieListItem(movie = movie) {}
}