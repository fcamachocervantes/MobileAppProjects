package com.csci448.fcamachocervantes_a3.presentation.navigation


import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.csci448.fcamachocervantes_a3.presentation.navigation.specs.IScreenSpec
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.IMovieViewModel

@Composable
fun MovieTopBar(
    movieViewModel: IMovieViewModel,
    navHostController: NavHostController,
    context: Context
){
    val navBackStackEntryState = navHostController.currentBackStackEntryAsState()
    IScreenSpec.TopBar(
        movieViewModel = movieViewModel,
        navController = navHostController,
        navBackStackEntry = navBackStackEntryState.value,
        context = context
    )
}