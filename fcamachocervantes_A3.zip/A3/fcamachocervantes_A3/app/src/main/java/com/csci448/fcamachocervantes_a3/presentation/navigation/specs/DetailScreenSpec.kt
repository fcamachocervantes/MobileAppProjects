package com.csci448.fcamachocervantes_a3.presentation.navigation.specs

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.*
import com.csci448.fcamachocervantes_a3.presentation.detail.MovieDetailScreen
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.IMovieViewModel
import com.csci448.fcamachocervantes_a3.R
import kotlinx.coroutines.CoroutineScope
import java.util.*
import kotlin.coroutines.CoroutineContext

object DetailScreenSpec : IScreenSpec {
    private const val LOG_TAG = "448.DetailScreenSpec"

    private const val ROUTE_BASE = "detail"
    private const val ARG_UUID_NAME = "uuid"

    private fun buildFullRoute(argVal: String): String {
        var fullRoute = ROUTE_BASE
        if(argVal == ARG_UUID_NAME) {
            fullRoute += "/{$argVal}"
            Log.d(LOG_TAG, "Built base route $fullRoute")
        } else {
            fullRoute += "/$argVal"
            Log.d(LOG_TAG, "Built specific route $fullRoute")
        }
        return fullRoute
    }

    override val route = buildFullRoute(ARG_UUID_NAME)

    override val arguments: List<NamedNavArgument> = listOf(
        navArgument(ARG_UUID_NAME) {
            type = NavType.StringType
        }
    )

    override fun buildRoute(vararg args: String?): String = buildFullRoute(args[0] ?: "0")

    override val title = R.string.movie_database

    @Composable
    override fun Content(
        movieViewModel: IMovieViewModel,
        navController: NavHostController,
        navBackStackEntry: NavBackStackEntry,
        context: Context,
        coroutineScope: CoroutineScope
    ) {
        Log.d(LOG_TAG, "backStackEntryContents ${navBackStackEntry.arguments}")
        val uuid = navBackStackEntry.arguments?.getString("uuid")?.let{
            it
        }
        if(uuid != null){
            movieViewModel.loadMovieByUUID(uuid)
        }
        val movie = movieViewModel.currentMovieState.collectAsState().value

        if(movie != null){
            MovieDetailScreen(
                movie = movie
            )
        }
    }

    @Composable
    override fun TopAppBarActions(
        movieViewModel: IMovieViewModel,
        navController: NavHostController,
        navBackStackEntry: NavBackStackEntry?,
        context: Context
    ) {
        val uuid = navBackStackEntry?.arguments?.getString("uuid")?.let{
            it
        }
        movieViewModel.loadMovieByUUID(uuid!!)
        val movieState = movieViewModel.currentMovieState.collectAsState()
        val movie = movieState.value

        IconButton(onClick = {
            movieViewModel.deleteMovie(movie!!)
            navController.popBackStack(route = ListScreenSpec.buildRoute(), inclusive = false)
        }
        ) {
            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = stringResource(id = R.string.menu_delete_movie_desc)
            )
        }
    }

}