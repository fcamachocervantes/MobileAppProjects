package com.csci448.fcamachocervantes_a3.util.api

import com.csci448.fcamachocervantes_a3.data.Movie
import retrofit2.Call
import retrofit2.http.GET

interface A3ApiService {
    companion object {
        const val BASE_API_URL = "https://imdb8.p.rapidapi.com/"
    }

    @GET("auto-complete")
    fun getMovie(): Call<Movie>
    @GET("title/get-videos")
    fun getVideos(): Call<Movie>
}