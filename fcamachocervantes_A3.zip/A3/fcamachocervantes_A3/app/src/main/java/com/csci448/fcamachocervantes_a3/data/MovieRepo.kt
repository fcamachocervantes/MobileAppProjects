package com.csci448.fcamachocervantes_a3.data

import android.content.Context
import com.csci448.fcamachocervantes_a3.data.database.MovieDao
import com.csci448.fcamachocervantes_a3.data.database.MovieDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.util.*

class MovieRepo @OptIn(DelicateCoroutinesApi::class)
private constructor(private val movieDao: MovieDao, private val coroutineScope: CoroutineScope = GlobalScope) {
    companion object {
        private const val LOG_TAG = "448.MovieRepo"
        @Volatile private var INSTANCE: MovieRepo? = null

        fun getInstance(context: Context): MovieRepo {
            synchronized(this) {
                var instance = INSTANCE
                if(instance == null) {
                    val database = MovieDatabase.getInstance(context)
                    instance = MovieRepo(database.movieDao)
                    INSTANCE = instance
                }
                return instance
            }
        }
    }

    fun addMovie(movie: Movie) {
        coroutineScope.launch {
            movieDao.addMovie(movie)
        }
    }
    fun getMovies(): Flow<List<Movie>> = movieDao.getMovies()
    suspend fun getMovieById(id: String): Movie? = movieDao.getMovieById(id)
    fun deleteMovie(movie: Movie) {
        coroutineScope.launch {
            movieDao.deleteMovie(movie)
        }
    }
}