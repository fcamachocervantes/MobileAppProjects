package com.csci448.fcamachocervantes_a3.presentation.list

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.csci448.fcamachocervantes_a3.data.Movie
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.PreviewMovieViewModel

@Composable
fun MovieListScreen(movieList: List<Movie>,
                    onSelectMovie: (Movie) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        items(movieList) { movie ->
            MovieListItem(movie = movie, onSelectMovie = onSelectMovie)
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun PreviewSamodelkinListScreen() {
    val context = LocalContext.current
    val viewModel = PreviewMovieViewModel(context)

    val movie = Movie("The Mandalorian", "Scifi", "Pedro Pascal", "2023", 9, "210480", "")
    val movie2 = Movie("The Mandalorian", "Scifi", "Pedro Pascal", "2023", 9, "210480", "")
    val movieList = listOf(movie, movie2)
    MovieListScreen(movieList = movieList) {}
}