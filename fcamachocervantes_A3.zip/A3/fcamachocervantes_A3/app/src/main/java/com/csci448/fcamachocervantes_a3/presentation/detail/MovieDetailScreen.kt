package com.csci448.fcamachocervantes_a3.presentation.detail

import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.csci448.fcamachocervantes_a3.data.Movie

@Composable
fun MovieDetailScreen(movie: Movie) {
    MovieDetails(movie = movie)
}

@Preview(showBackground = true)
@Composable
private fun PreviewMovieDetailScreen() {
    val context = LocalContext.current
    val movie = Movie(
        "Game of Thrones",
        "TV Series",
        "Peter Dinklage",
        "2011-2019",
        26,
        "tt0944947",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQaEFnTagipxGek320Ytdkfar67mGKRrTgb4YhvIq1bKxjGDZ5"
    )
    MovieDetailScreen(movie = movie)
}