package com.csci448.fcamachocervantes_a3.data.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.csci448.fcamachocervantes_a3.data.Movie
import kotlinx.coroutines.flow.Flow
import java.util.*

@Dao
interface MovieDao {
    @Insert
    fun addMovie(movie: Movie)
    @Query("SELECT * FROM movie")
    fun getMovies(): Flow<List<Movie>>
    @Query("SELECT * FROM movie WHERE id=(:id)")
    suspend fun getMovieById(id: String): Movie?
    @Delete
    suspend fun deleteMovie(movie: Movie)
}