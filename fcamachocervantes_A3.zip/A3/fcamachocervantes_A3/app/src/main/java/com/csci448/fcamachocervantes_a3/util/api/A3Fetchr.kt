package com.csci448.fcamachocervantes_a3.util.api

import android.util.Log
import com.csci448.fcamachocervantes_a3.data.Movie
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*

class A3Fetchr {
    private val LOG_TAG = "448.SamodelkinFetchr"

    private val a3ApiService : A3ApiService

    private val mMovieState = MutableStateFlow<Movie?>(null)

    private val mVideoListState = MutableStateFlow<List<String>>(listOf(""))

    val movieState: StateFlow<Movie?>
        get()= mMovieState.asStateFlow()

    val videoListState: StateFlow<List<String>>
        get() = mVideoListState.asStateFlow()

    init {
        val retrofit = Retrofit
            .Builder()
            .baseUrl(A3ApiService.BASE_API_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        a3ApiService = retrofit.create(A3ApiService::class.java)
    }

    //retrieves a single movie from the imdb data base
    fun getMovie() {
        val movieRequest = a3ApiService.getMovie()
        movieRequest.enqueue(
            object : Callback<Movie> {
                override fun onFailure(call: Call<Movie>, t: Throwable
                ){
                    Log.e(LOG_TAG, "onFailure() called $t")
                    mMovieState.update {null}
                }
                override fun onResponse(call: Call<Movie>,
                                        response: Response<Movie>
                ){
                    Log.d(LOG_TAG, "onResponse() Called")
                    val responseMovie = response.body()
                    if(responseMovie == null){
                        Log.d(LOG_TAG, "onResponse() Returned Null Movie")
                        mMovieState.update { null }
                    }
                    else {
                        val newMovie = responseMovie.copy(
                        )
                        Log.d(LOG_TAG, "newMovie: $newMovie")
                        mMovieState.update { newMovie }
                    }
                }
            }
        )
    }


    //This function will receive the list of video urls for a specific movie and update
    //the list of video urls so that they can be retrieved in the correct screen and show
    //trailers as buttons
    fun getVideos() {

    }
}