package com.csci448.fcamachocervantes_a3.presentation.newmovie

import android.content.res.Configuration
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.csci448.fcamachocervantes_a3.data.Movie
import com.csci448.fcamachocervantes_a3.presentation.detail.MovieDetails
import com.csci448.fcamachocervantes_a3.R
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.IMovieViewModel
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.PreviewMovieViewModel

@Composable
fun NewMovieScreen(
    movieViewModel: IMovieViewModel,
    movie: Movie,
    onSaveMovie: () -> Unit,
    apiButtonIsEnabled: Boolean,
    onRequestApiMovie: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        NewMovieSearchBox(
            movieText = movieViewModel.currentMovieString.value,
            onNewMovieValue = { movieViewModel.currentMovieString.value = it
                                onRequestApiMovie(movieViewModel.currentMovieString.value!!) },
            apiButtonIsEnabled = apiButtonIsEnabled
        )

        NewMovieButton(
            text = stringResource(R.string.save_to_list_label),
            onClick = { onSaveMovie },
            enabled = apiButtonIsEnabled
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun PreViewNewMovieSceen() {
    val context = LocalContext.current
    val viewModel = PreviewMovieViewModel(context)
    val movie = Movie(
        "Game of Thrones",
        "Drama",
        "Peter Dinklage",
        "2011-2019",
        26,
        "tt0944947",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQaEFnTagipxGek320Ytdkfar67mGKRrTgb4YhvIq1bKxjGDZ5"
    )


    NewMovieScreen(
        movieViewModel = viewModel,
        movie = movie,
        onRequestApiMovie = { },
        onSaveMovie = { Movie(
            "Game of Thrones",
            "Drama",
            "Peter Dinklage",
            "2011-2019",
            26,
            "tt0944947",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQaEFnTagipxGek320Ytdkfar67mGKRrTgb4YhvIq1bKxjGDZ5"
        ) },
        apiButtonIsEnabled = false
    )
}