package com.csci448.fcamachocervantes_a3.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.csci448.fcamachocervantes_a3.data.Movie

@Database(entities = [Movie::class], version = 1)
@TypeConverters(MovieTypeConverters::class)
abstract class MovieDatabase : RoomDatabase (){
    companion object {
        @Volatile private  var INSTANCE: MovieDatabase? = null
        fun getInstance(context: Context): MovieDatabase {
            synchronized(this) {
                var instance = INSTANCE
                if(instance == null) {
                    instance = Room.databaseBuilder(
                        context = context,
                        klass = MovieDatabase::class.java,
                        name = "movie-database"
                    ).build()
                    INSTANCE = instance
                }
                return instance
            }
        }
    }

    abstract val movieDao: MovieDao
}