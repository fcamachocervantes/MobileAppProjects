package com.csci448.fcamachocervantes_a3.presentation.newmovie

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview


@Composable
fun NewMovieButton(text: String,
                       enabled: Boolean = true,
                       onClick: () -> Unit
) {
    Button(
        modifier = Modifier.fillMaxWidth(),
        enabled = enabled,
        onClick = onClick
    ) {
        Text(
            text = text,
            textAlign = TextAlign.Center
        )
    }
}

@Preview
@Composable
private fun PreviewNewMovieButton() {
    NewMovieButton(
        text = "Save Movie",
        enabled = true,
        onClick = {}
    )
}

@Preview
@Composable
private fun PreviewNewMovieButtonDisabled() {
    NewMovieButton(
        text = "Save Movie",
        enabled = false,
        onClick = {}
    )
}