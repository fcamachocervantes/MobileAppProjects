package com.csci448.fcamachocervantes_a3.presentation.navigation.specs

import android.content.Context
import android.util.Log
import androidx.compose.runtime.*
import androidx.navigation.NamedNavArgument
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import com.csci448.fcamachocervantes_a3.data.Movie
import com.csci448.fcamachocervantes_a3.presentation.newmovie.NewMovieScreen
import com.csci448.fcamachocervantes_a3.presentation.viewmodel.IMovieViewModel
import com.csci448.fcamachocervantes_a3.util.NetworkConnectionUtil
import com.csci448.fcamachocervantes_a3.util.api.A3Fetchr
import com.csci448.fcamachocervantes_a3.R
import kotlinx.coroutines.CoroutineScope

object NewMovieScreenSpec : IScreenSpec{
    private const val LOG_TAG = "448.NewMovieSceenSpec"

    override val route = "newMovie"
    override val arguments: List<NamedNavArgument> = emptyList()
    override fun buildRoute(vararg args: String?): String = route
    override val title = R.string.movie_database

    @Composable
    override fun Content(
        movieViewModel: IMovieViewModel,
        navController: NavHostController,
        navBackStackEntry: NavBackStackEntry,
        context: Context,
        coroutineScope: CoroutineScope
    ) {
        val movieState = remember {
            mutableStateOf( Movie("", "", "", "", 0, "", "") )
        }

        val movieFetchr = remember {
            A3Fetchr()
        }
        val apiMovieState = movieFetchr.movieState
            .collectAsState(context = coroutineScope.coroutineContext)

        LaunchedEffect(key1 = apiMovieState.value) {
            val apiMovie = apiMovieState.value
            if(apiMovie != null){
                Log.d(LOG_TAG, "Valid Movie $apiMovie")
                movieState.value = apiMovie
            }
            else {
                Log.d(LOG_TAG, "Null Movie")
                movieState.value = Movie("", "", "", "", 0, "", "")
            }
        }

        NewMovieScreen(
            movieViewModel = movieViewModel,
            movie = movieState.value,
            onSaveMovie = {
                movieViewModel.addMovie(movieState.value)
                navController.popBackStack(route = ListScreenSpec.buildRoute(), inclusive = false)
            },
            apiButtonIsEnabled = movieViewModel.currentMovieString.value != null && NetworkConnectionUtil.isNetworkAvailableAndConnected(context),
            onRequestApiMovie = { movieFetchr.getMovie() }
        )
    }

    @Composable
    override fun TopAppBarActions(
        movieViewModel: IMovieViewModel,
        navController: NavHostController,
        navBackStackEntry: NavBackStackEntry?,
        context: Context
    ) {

    }
}