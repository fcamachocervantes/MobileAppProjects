package com.csci448.fcamachocervantes_a3.presentation.viewmodel

import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.csci448.fcamachocervantes_a3.data.Movie
import com.csci448.fcamachocervantes_a3.data.MovieRepo
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*

class MovieViewModel(private val movieRepo: MovieRepo) : ViewModel(), IMovieViewModel{
    companion object {
        private const val LOG_TAG = "448.MovieViewModel"
    }
    private val mMovies: MutableStateFlow<List<Movie>> = MutableStateFlow(emptyList())

    /**
     * holds list of all characters stored within the view model
     */
    override val movieListState: StateFlow<List<Movie>>
        get() = mMovies.asStateFlow()

    private val mCurrentMovieIdState: MutableStateFlow<String> = MutableStateFlow("")

    private val mCurrentMovieState: MutableStateFlow<Movie?> = MutableStateFlow(null)

    override val currentMovieState: StateFlow<Movie?>
        get() = mCurrentMovieState.asStateFlow()

    override val currentMovieString: MutableState<String?> = mutableStateOf("")

    init {
        viewModelScope.launch {
            movieRepo.getMovies().collect{ movieList ->
                mMovies.update { movieList }
            }
        }
        viewModelScope.launch {
            mCurrentMovieIdState
                .map { uuid -> movieRepo.getMovieById(uuid) }
                .collect { movie -> mCurrentMovieState.update { movie } }
        }
    }

    override fun loadMovieByUUID(uuid: String) {
        mCurrentMovieIdState.update { uuid }
        Log.d(LOG_TAG, "Movie not found")
    }

    override fun addMovie(movieToAdd: Movie) {
        Log.d(LOG_TAG, "adding movie $movieToAdd")
        movieRepo.addMovie(movieToAdd)
    }

    override fun deleteMovie(movieToDelete: Movie) {
        Log.d(LOG_TAG, "deleting movie $movieToDelete")
        movieRepo.deleteMovie(movieToDelete)
    }
}