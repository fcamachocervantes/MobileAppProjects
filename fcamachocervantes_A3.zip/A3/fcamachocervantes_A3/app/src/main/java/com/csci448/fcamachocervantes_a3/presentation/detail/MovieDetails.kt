package com.csci448.fcamachocervantes_a3.presentation.detail

import android.content.res.Configuration
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.util.Log
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import coil.compose.AsyncImage
import com.csci448.fcamachocervantes_a3.data.Movie

private const val LOG_TAG = "448.MovieDetails"

@Composable
fun MovieDetails(movie: Movie) {
    val imageSize = with(LocalDensity.current) { 384.toDp() }
    Column(
        modifier = Modifier.padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .padding(end = 16.dp)
                    .width(imageSize)
                    .height(imageSize)
            ) {
                Log.d(LOG_TAG, "Displaying Movie Art \"${movie.imageUrl}\"")
                ArtImage(
                    imageSize = imageSize,
                    imageUrl = movie.imageUrl
                )
            }
            Column(
                modifier = Modifier.weight(0.5f)
            ) {
                MovieDetailsSection(movie)
            }
        }
    }
}

@Composable
private fun MovieDetailsSection(movie: Movie) {
    Column(
        modifier = Modifier
            .fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(movie.name)
        Text(movie.stars)
        Text("Year: ${movie.year}")
        Text("IMDB Rank:  ${movie.rank}")
        Text("Genre: ${movie.genre}")
    }
}

@Composable
private fun ArtImage(imageSize: Dp, imageUrl: String?) {
    if (imageUrl != null) {
        AsyncImage(
            modifier = Modifier
                .width(imageSize)
                .height(imageSize)
                .padding(4.dp),
            model = imageUrl,
            contentDescription = "Movie Key Art"
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun PreviewMovieDetails() {
    val context = LocalContext.current
    val movie = Movie(
        "Game of Thrones",
        "Drama",
        "Peter Dinklage",
        "2011-2019",
        26,
        "tt0944947",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQaEFnTagipxGek320Ytdkfar67mGKRrTgb4YhvIq1bKxjGDZ5"
    )
    MovieDetails(movie = movie)
}