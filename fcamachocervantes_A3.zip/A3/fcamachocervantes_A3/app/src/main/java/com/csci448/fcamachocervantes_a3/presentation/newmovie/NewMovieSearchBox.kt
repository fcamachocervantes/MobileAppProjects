package com.csci448.fcamachocervantes_a3.presentation.newmovie

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.csci448.fcamachocervantes_a3.R

@Composable
fun NewMovieSearchBox(movieText: String?,
                      onNewMovieValue: (String) -> Unit,
                      apiButtonIsEnabled: Boolean

){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
    ) {
        Text(
            modifier = Modifier
                .padding(top = 20.dp, bottom = 20.dp),
            text = stringResource(id = R.string.search_movie_label)
        )
        if (movieText != null) {
            TextField(
                value = movieText,
                onValueChange = { onNewMovieValue(it) },
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun EnterMovieBox() {
    NewMovieSearchBox(movieText = "", onNewMovieValue = {}, true)
}