package com.csci448.fcamachocervantes_a3.presentation.viewmodel

import android.content.Context
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import com.csci448.fcamachocervantes_a3.data.Movie
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.*

class PreviewMovieViewModel(context: Context) : IMovieViewModel{
    companion object {
        private const val LOG_TAG = "448.PreviewMovieViewModel"
    }

    private val mMovies: MutableList<Movie> = mutableListOf()

    private var mMovieListState = MutableStateFlow(mMovies.toList())

    private val mCurrentMovieState: MutableStateFlow<Movie?> = MutableStateFlow(null)

    override val movieListState: StateFlow<List<Movie>>
        get() = mMovieListState.asStateFlow()

    override val currentMovieState: StateFlow<Movie?>
        get() = mCurrentMovieState.asStateFlow()

    override val currentMovieString: MutableState<String?> = mutableStateOf("")

    override fun loadMovieByUUID(uuid: String) {
        Log.d(LOG_TAG, "loadMovieByUUID($uuid)")
        mCurrentMovieState.value = null
        mMovies.forEach { movie ->
            if(movie.id == uuid) {
                Log.d(LOG_TAG, "Movie found! $movie")
                mCurrentMovieState.value = movie
                return
            }
        }
        Log.d(LOG_TAG, "Movie not found")
        return
    }

    override fun addMovie(movieToAdd: Movie) {
        Log.d(LOG_TAG, "adding movie $movieToAdd")
        mMovies += movieToAdd
        mMovieListState = MutableStateFlow(mMovies.toList())
    }

    override fun deleteMovie(movieToDelete: Movie) {
        Log.d(LOG_TAG, "deleting movie $movieToDelete")
        mMovies.forEach { movie ->
            if(movie.id == movieToDelete.id) {
                mMovies.remove(movie)
                mMovieListState = MutableStateFlow(mMovies.toList())
                if(mCurrentMovieState.value == movie) {
                    mCurrentMovieState.value = null
                }
                Log.d(LOG_TAG, "movie deleted")
                return
            }
        }
        Log.d(LOG_TAG, "movie not found")
    }
}